Node JS (nodejs-express-mysql)

In this tutorial, we need 3 dependencies below:

1. Express (node.js framework)

2. MySQL (MySQL driver for node.js)

3. Body-parser (middleware to handle post body request)


Create package.json, you can run the following command on the terminal.

> npm init

The above command will automatically create a file called package.json on your project.

After that,

Install all the dependencies needed by typing the following command in the terminal:

> npm install --save express mysql body-parser

POSTMAN COLLECTION : https://www.getpostman.com/collections/a56225820ab4226e27b7